package com.masai.DTO;

public class MovieGenre {

	private String genre;
	private String primaryTitle;
	private Integer numVotes;
}
