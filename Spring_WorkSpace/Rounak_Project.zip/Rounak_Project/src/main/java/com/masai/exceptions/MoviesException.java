package com.masai.exceptions;

public class MoviesException extends Exception {

	public MoviesException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MoviesException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
